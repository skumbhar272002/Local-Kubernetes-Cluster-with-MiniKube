from django.contrib import admin

from Admin_Dashboard.models import Department
admin.site.register(Department)